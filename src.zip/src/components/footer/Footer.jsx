import React from "react";

const Footer = () => {
  return <footer className="footer text-center">فوتر</footer>;
};

export default Footer;
